## Tickets

https://github.com/serengil/deepface/issues/XXX

### What has been done

With this PR, ...

## How to test

```shell
make lint && make test
```