<script setup lang="ts"></script>

<template>
  <h3>无用页面</h3>
</template>

<style lang="scss" scoped></style>
